voting web application using django framework by Mydeen fathima
